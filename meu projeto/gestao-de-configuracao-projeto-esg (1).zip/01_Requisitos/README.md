# Requisitos do Sistema

Este diretório contém os documentos relacionados aos requisitos do projeto, incluindo:

- Especificação de requisitos funcionais e não funcionais;
- Revisão e validação de requisitos;
- Registro de alterações e controle de versões.

Esses artefatos seguem as boas práticas de **Governança**, **ITIL** e **COBIT**, garantindo rastreabilidade e segurança na gestão de configuração.
