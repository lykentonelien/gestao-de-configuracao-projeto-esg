# Diagramas

Este diretório contém os diagramas UML, fluxogramas e representações visuais do sistema, usados para o entendimento e documentação do projeto.
