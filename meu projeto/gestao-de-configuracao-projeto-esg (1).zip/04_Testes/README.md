# Testes

Contém casos de teste, resultados e registros de validação do software.
