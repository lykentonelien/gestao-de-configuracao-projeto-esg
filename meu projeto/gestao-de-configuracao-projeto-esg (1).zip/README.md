# Gestão de Configuração – Projeto com Foco em Governança, ITIL, COBIT e ESG

## 🎯 Objetivo
Este repositório foi criado para armazenar e controlar os artefatos do projeto de software, conforme boas práticas de **Governança de TI**, **ITIL**, **COBIT** e **ESG (Environmental, Social and Governance)**.

## 🧩 Frameworks e Princípios
- **ITIL:** aplicado na gestão de mudanças e controle de versões.
- **COBIT:** garante alinhamento entre objetivos de negócio e de TI.
- **Governança:** promove transparência, responsabilidade e conformidade.
- **ESG:** incentiva práticas sustentáveis e sociais no ambiente de TI.

## 🗂️ Estrutura do Repositório
- `01_Requisitos/` → documentos de requisitos e validação.  
- `02_Diagramas/` → diagramas UML, de classes e casos de uso.  
- `03_Codigo_Fonte/` → código-fonte do sistema.  
- `04_Testes/` → casos de teste e resultados.  
- `05_Documentacao/` → manuais e guias técnicos.  
- `06_Governanca/` → políticas, planos ITIL, controles COBIT e relatórios ESG.

## 🔐 Gestão de Configuração
Todas as alterações são rastreadas via controle de versão (commits e histórico).  
Isso garante auditoria, integridade e recuperação de versões anteriores, conforme ITIL e COBIT.

## ♻️ Sustentabilidade (ESG)
O projeto é hospedado em ambiente de nuvem, reduzindo o consumo de recursos físicos e promovendo práticas sustentáveis.

---

👤 **Responsável:** Lykenton Elien  
📚 *Projeto acadêmico – Anhanguera*
